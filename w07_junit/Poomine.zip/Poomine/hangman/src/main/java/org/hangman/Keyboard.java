package org.hangman;

public interface Keyboard {
    public String getInput();
}
