package org.hangman;

public interface Draw {
    public String draw(int num);
}